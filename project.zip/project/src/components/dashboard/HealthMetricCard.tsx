import React from 'react';
import { ArrowDown, ArrowUp } from 'lucide-react';

interface HealthMetricCardProps {
  title: string;
  value: string;
  unit?: string;
  status: 'normal' | 'warning' | 'alert';
  icon: React.ReactNode;
  trend?: number;
  progress?: number;
  target?: string;
  lastChecked?: string;
}

const HealthMetricCard: React.FC<HealthMetricCardProps> = ({
  title,
  value,
  unit,
  status,
  icon,
  trend,
  progress,
  target,
  lastChecked
}) => {
  const getStatusClasses = () => {
    switch (status) {
      case 'normal':
        return 'bg-success-50 border-success-200';
      case 'warning':
        return 'bg-warning-50 border-warning-200';
      case 'alert':
        return 'bg-error-50 border-error-200';
      default:
        return 'bg-gray-50 border-gray-200';
    }
  };

  return (
    <div className={`card p-4 border ${getStatusClasses()} hover:shadow-md transition-all duration-200`}>
      <div className="flex items-start justify-between mb-2">
        <h3 className="text-sm font-medium text-gray-600">{title}</h3>
        <div className="h-6 w-6">{icon}</div>
      </div>
      
      <div className="flex items-end mb-1">
        <span className="text-2xl font-bold text-gray-900">{value}</span>
        {unit && <span className="ml-1 text-sm text-gray-500">{unit}</span>}
        
        {trend !== undefined && (
          <div className={`ml-2 flex items-center text-xs ${trend >= 0 ? 'text-error-500' : 'text-success-500'}`}>
            {trend >= 0 ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />}
            <span>{Math.abs(trend)}%</span>
          </div>
        )}
      </div>
      
      {progress !== undefined && target && (
        <div className="mt-2">
          <div className="w-full bg-gray-200 rounded-full h-1.5 mb-1">
            <div 
              className={`h-1.5 rounded-full ${
                status === 'normal' ? 'bg-success-500' : 
                status === 'warning' ? 'bg-warning-500' : 'bg-error-500'
              }`} 
              style={{ width: `${progress * 100}%` }}
            ></div>
          </div>
          <div className="flex justify-between text-xs text-gray-500">
            <span>Progress</span>
            <span>Target: {target}</span>
          </div>
        </div>
      )}
      
      {lastChecked && (
        <div className="text-xs text-gray-500 mt-1">
          Last checked: {lastChecked}
        </div>
      )}
    </div>
  );
};

export default HealthMetricCard;