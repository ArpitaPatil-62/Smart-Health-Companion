import React, { useEffect, useRef } from 'react';
import { Chart, registerables } from 'chart.js';

Chart.register(...registerables);

const TrendChart: React.FC = () => {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);

  useEffect(() => {
    if (chartRef.current) {
      // Destroy existing chart instance if it exists
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }

      const ctx = chartRef.current.getContext('2d');
      
      if (ctx) {
        // Sample data
        const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
        
        // Animate on load
        const animate = {
          duration: 1000,
          easing: 'easeOutQuart',
        };

        chartInstance.current = new Chart(ctx, {
          type: 'line',
          data: {
            labels: days,
            datasets: [
              {
                label: 'Heart Rate (bpm)',
                data: [75, 72, 80, 70, 75, 68, 72],
                borderColor: '#F97066', // Secondary color
                backgroundColor: 'rgba(249, 112, 102, 0.1)',
                tension: 0.4,
                fill: true,
              },
              {
                label: 'Steps',
                data: [5200, 6800, 7500, 4300, 8900, 9200, 6500],
                borderColor: '#0EA5E9', // Primary color
                backgroundColor: 'rgba(14, 165, 233, 0.1)',
                tension: 0.4,
                fill: true,
              }
            ]
          },
          options: {
            responsive: true,
            animation: animate,
            plugins: {
              legend: {
                position: 'top',
                labels: {
                  usePointStyle: true,
                  boxWidth: 6,
                }
              },
              tooltip: {
                mode: 'index',
                intersect: false,
              }
            },
            scales: {
              x: {
                grid: {
                  display: false,
                },
              },
              y: {
                grid: {
                  borderDash: [2, 4],
                  color: '#f1f5f9', // Light gray
                },
                beginAtZero: false,
              }
            },
            elements: {
              point: {
                radius: 3,
                hoverRadius: 5,
              }
            },
            interaction: {
              mode: 'nearest',
              intersect: false,
              axis: 'x'
            },
          }
        });
      }
    }

    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, []);

  return (
    <div className="w-full">
      <canvas ref={chartRef}></canvas>
    </div>
  );
};

export default TrendChart;