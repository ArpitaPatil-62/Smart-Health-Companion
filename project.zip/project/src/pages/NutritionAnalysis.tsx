import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Utensils, 
  Camera, 
  PieChart, 
  Droplet, 
  Clock, 
  Plus, 
  Search,
  Info,
  ChevronRight
} from 'lucide-react';

const NutritionAnalysis: React.FC = () => {
  const [activeTab, setActiveTab] = useState('log');
  
  return (
    <div className="space-y-6">
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex items-center mb-1">
          <Utensils className="h-6 w-6 text-accent-500 mr-2" />
          <h1 className="text-2xl font-bold text-gray-900">Nutrition Analysis</h1>
        </div>
        <p className="text-gray-600">Track your meals and get personalized nutrition insights</p>
      </motion.div>
      
      <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-1 flex mb-6">
        <button
          className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
            activeTab === 'log'
              ? 'bg-primary-50 text-primary-700'
              : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
          }`}
          onClick={() => setActiveTab('log')}
        >
          Daily Log
        </button>
        <button
          className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
            activeTab === 'analysis'
              ? 'bg-primary-50 text-primary-700'
              : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
          }`}
          onClick={() => setActiveTab('analysis')}
        >
          Analysis
        </button>
        <button
          className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
            activeTab === 'plan'
              ? 'bg-primary-50 text-primary-700'
              : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
          }`}
          onClick={() => setActiveTab('plan')}
        >
          Meal Plan
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="lg:col-span-2"
        >
          {activeTab === 'log' && (
            <DailyLogTab />
          )}
          
          {activeTab === 'analysis' && (
            <AnalysisTab />
          )}
          
          {activeTab === 'plan' && (
            <MealPlanTab />
          )}
        </motion.div>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <div className="space-y-6">
            <div className="card p-4">
              <h2 className="text-lg font-semibold text-gray-900 mb-3">Daily Progress</h2>
              
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm font-medium text-gray-700">Calories</span>
                    <span className="text-sm text-gray-600">1,450 / 2,200</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div className="bg-primary-500 h-2.5 rounded-full" style={{ width: '65%' }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm font-medium text-gray-700">Protein</span>
                    <span className="text-sm text-gray-600">75g / 120g</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div className="bg-secondary-500 h-2.5 rounded-full" style={{ width: '62%' }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm font-medium text-gray-700">Carbs</span>
                    <span className="text-sm text-gray-600">180g / 250g</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div className="bg-accent-500 h-2.5 rounded-full" style={{ width: '72%' }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm font-medium text-gray-700">Fats</span>
                    <span className="text-sm text-gray-600">45g / 70g</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div className="bg-warning-500 h-2.5 rounded-full" style={{ width: '64%' }}></div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="card p-4">
              <h2 className="text-lg font-semibold text-gray-900 mb-3">Your Goal</h2>
              <div className="p-3 bg-primary-50 rounded-lg mb-3">
                <p className="text-sm font-medium text-gray-900">Weight Loss</p>
                <p className="text-xs text-gray-600">0.5 kg per week</p>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Daily Target</span>
                  <span className="text-sm font-medium text-gray-800">2,200 calories</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Current Weight</span>
                  <span className="text-sm font-medium text-gray-800">72 kg</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Goal Weight</span>
                  <span className="text-sm font-medium text-gray-800">65 kg</span>
                </div>
              </div>
              
              <button className="mt-3 text-sm text-primary-600 hover:text-primary-700 w-full text-center">
                Update Goals
              </button>
            </div>
            
            <div className="card p-4">
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-lg font-semibold text-gray-900">Water Intake</h2>
                <Droplet className="h-5 w-5 text-primary-500" />
              </div>
              
              <div className="flex items-end mb-3">
                <div className="relative w-24 h-28 bg-gray-100 rounded-lg overflow-hidden">
                  <div 
                    className="absolute bottom-0 w-full bg-primary-200 transition-all duration-500"
                    style={{ height: '40%' }}
                  ></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-lg font-semibold text-primary-700">40%</span>
                  </div>
                </div>
                
                <div className="ml-4 flex-1">
                  <p className="text-sm font-medium text-gray-900">1.2L / 3.0L</p>
                  <p className="text-xs text-gray-600 mt-1">You're behind on your daily water goal</p>
                  
                  <div className="mt-3 flex">
                    <button className="btn btn-outline text-xs py-1 px-2 mr-2">
                      +250ml
                    </button>
                    <button className="btn btn-primary text-xs py-1 px-2">
                      +500ml
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

const DailyLogTab: React.FC = () => {
  return (
    <div className="card p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold text-gray-900">Today's Food Log</h2>
        <div className="flex space-x-2">
          <button className="btn btn-outline py-1 px-3 text-sm">
            <Camera className="h-4 w-4 mr-1" />
            Photo Log
          </button>
          <button className="btn btn-primary py-1 px-3 text-sm">
            <Plus className="h-4 w-4 mr-1" />
            Add Food
          </button>
        </div>
      </div>
      
      <div className="space-y-6">
        <MealSection 
          title="Breakfast"
          time="7:30 AM"
          items={[
            { name: "Oatmeal with berries", calories: 320, protein: 12, carbs: 45, fat: 8 },
            { name: "Black coffee", calories: 5, protein: 0, carbs: 0, fat: 0 },
          ]}
        />
        
        <MealSection 
          title="Lunch"
          time="12:15 PM"
          items={[
            { name: "Chicken salad with vinaigrette", calories: 420, protein: 35, carbs: 15, fat: 22 },
            { name: "Whole grain bread", calories: 120, protein: 4, carbs: 22, fat: 2 },
            { name: "Apple", calories: 95, protein: 0, carbs: 25, fat: 0 },
          ]}
        />
        
        <MealSection 
          title="Snack"
          time="3:45 PM"
          items={[
            { name: "Greek yogurt", calories: 150, protein: 15, carbs: 8, fat: 5 },
            { name: "Almonds (1oz)", calories: 160, protein: 6, carbs: 6, fat: 14 },
          ]}
        />
        
        <MealSection 
          title="Dinner"
          time="7:00 PM"
          items={[
            { name: "Salmon fillet (4oz)", calories: 180, protein: 23, carbs: 0, fat: 9 },
            { name: "Quinoa (1/2 cup)", calories: 110, protein: 4, carbs: 20, fat: 2 },
            { name: "Roasted vegetables", calories: 90, protein: 2, carbs: 15, fat: 3 },
          ]}
          showAddNew
        />
      </div>
      
      <div className="mt-6 pt-4 border-t border-gray-100">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-medium text-gray-900">Today's Totals</h3>
          <div className="text-sm text-primary-600">1,450 kcal</div>
        </div>
        
        <div className="grid grid-cols-3 gap-2">
          <div className="text-center p-2 bg-gray-50 rounded-lg">
            <div className="text-xs text-gray-500 mb-1">Protein</div>
            <div className="font-medium text-gray-900">75g</div>
          </div>
          <div className="text-center p-2 bg-gray-50 rounded-lg">
            <div className="text-xs text-gray-500 mb-1">Carbs</div>
            <div className="font-medium text-gray-900">180g</div>
          </div>
          <div className="text-center p-2 bg-gray-50 rounded-lg">
            <div className="text-xs text-gray-500 mb-1">Fat</div>
            <div className="font-medium text-gray-900">45g</div>
          </div>
        </div>
      </div>
    </div>
  );
};

interface FoodItem {
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

interface MealSectionProps {
  title: string;
  time: string;
  items: FoodItem[];
  showAddNew?: boolean;
}

const MealSection: React.FC<MealSectionProps> = ({ title, time, items, showAddNew }) => {
  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <h3 className="font-medium text-gray-900">{title}</h3>
        <div className="flex items-center text-sm text-gray-500">
          <Clock className="h-3 w-3 mr-1" />
          {time}
        </div>
      </div>
      
      <div className="bg-gray-50 rounded-lg overflow-hidden">
        {items.map((item, index) => (
          <div 
            key={index} 
            className={`flex items-center justify-between p-3 ${
              index !== items.length - 1 ? 'border-b border-gray-100' : ''
            }`}
          >
            <div>
              <div className="text-sm font-medium text-gray-800">{item.name}</div>
              <div className="text-xs text-gray-500 mt-0.5">
                P: {item.protein}g • C: {item.carbs}g • F: {item.fat}g
              </div>
            </div>
            <div className="text-sm font-medium text-gray-700">{item.calories} kcal</div>
          </div>
        ))}
        
        {showAddNew && (
          <button className="w-full p-2 text-sm text-primary-600 hover:bg-gray-100 transition-colors flex items-center justify-center">
            <Plus className="h-4 w-4 mr-1" />
            Add Food to {title}
          </button>
        )}
      </div>
    </div>
  );
};

const AnalysisTab: React.FC = () => {
  return (
    <div className="card p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold text-gray-900">Nutrition Analysis</h2>
        <select className="input max-w-xs py-1 px-2 text-sm">
          <option>Last 7 Days</option>
          <option>Last 30 Days</option>
          <option>Last 3 Months</option>
        </select>
      </div>
      
      <div className="mb-6">
        <h3 className="font-medium text-gray-900 mb-3">Macro Distribution</h3>
        <div className="aspect-square max-w-[240px] mx-auto mb-4">
          <div className="bg-gray-100 rounded-full w-full h-full relative">
            {/* Simulated pie chart */}
            <div className="absolute inset-0 flex items-center justify-center">
              <PieChart className="h-10 w-10 text-gray-400" />
            </div>
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center">
              <div className="text-2xl font-bold text-gray-900">1,650</div>
              <div className="text-xs text-gray-500">avg. kcal/day</div>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <div className="rounded-full h-3 bg-primary-500 mb-1 mx-auto w-3/4"></div>
            <div className="text-sm font-medium">45%</div>
            <div className="text-xs text-gray-500">Carbs</div>
          </div>
          <div>
            <div className="rounded-full h-3 bg-secondary-500 mb-1 mx-auto w-1/2"></div>
            <div className="text-sm font-medium">30%</div>
            <div className="text-xs text-gray-500">Protein</div>
          </div>
          <div>
            <div className="rounded-full h-3 bg-accent-500 mb-1 mx-auto w-1/4"></div>
            <div className="text-sm font-medium">25%</div>
            <div className="text-xs text-gray-500">Fat</div>
          </div>
        </div>
      </div>
      
      <div className="mb-6 pb-5 border-b border-gray-100">
        <h3 className="font-medium text-gray-900 mb-3">Weekly Insights</h3>
        
        <div className="space-y-3">
          <div className="flex items-start p-3 bg-success-50 rounded-lg">
            <Info className="h-5 w-5 text-success-500 mr-2 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-medium text-gray-900">Good Protein Intake</h4>
              <p className="text-sm text-gray-600">You've consistently hit your protein targets this week, great for muscle maintenance.</p>
            </div>
          </div>
          
          <div className="flex items-start p-3 bg-warning-50 rounded-lg">
            <Info className="h-5 w-5 text-warning-500 mr-2 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-medium text-gray-900">High Sodium</h4>
              <p className="text-sm text-gray-600">Your sodium intake is 20% above recommended levels. Try reducing processed foods.</p>
            </div>
          </div>
          
          <div className="flex items-start p-3 bg-primary-50 rounded-lg">
            <Info className="h-5 w-5 text-primary-500 mr-2 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-medium text-gray-900">Low Fiber</h4>
              <p className="text-sm text-gray-600">Adding more fruits, vegetables and whole grains can help increase your fiber intake.</p>
            </div>
          </div>
        </div>
      </div>
      
      <div>
        <h3 className="font-medium text-gray-900 mb-3">Nutrient Details</h3>
        
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 bg-gray-50 rounded-lg">
              <div className="text-xs text-gray-500 mb-1">Sodium</div>
              <div className="flex items-end justify-between">
                <div className="text-lg font-medium text-gray-900">2,450mg</div>
                <div className="text-xs text-error-500">+20%</div>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
                <div className="bg-error-500 h-1.5 rounded-full" style={{ width: '120%' }}></div>
              </div>
            </div>
            
            <div className="p-3 bg-gray-50 rounded-lg">
              <div className="text-xs text-gray-500 mb-1">Fiber</div>
              <div className="flex items-end justify-between">
                <div className="text-lg font-medium text-gray-900">18g</div>
                <div className="text-xs text-warning-500">-10%</div>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
                <div className="bg-warning-500 h-1.5 rounded-full" style={{ width: '70%' }}></div>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 bg-gray-50 rounded-lg">
              <div className="text-xs text-gray-500 mb-1">Calcium</div>
              <div className="flex items-end justify-between">
                <div className="text-lg font-medium text-gray-900">950mg</div>
                <div className="text-xs text-success-500">+5%</div>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
                <div className="bg-success-500 h-1.5 rounded-full" style={{ width: '95%' }}></div>
              </div>
            </div>
            
            <div className="p-3 bg-gray-50 rounded-lg">
              <div className="text-xs text-gray-500 mb-1">Iron</div>
              <div className="flex items-end justify-between">
                <div className="text-lg font-medium text-gray-900">12mg</div>
                <div className="text-xs text-success-500">+20%</div>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
                <div className="bg-success-500 h-1.5 rounded-full" style={{ width: '120%' }}></div>
              </div>
            </div>
          </div>
        </div>
        
        <button className="mt-4 w-full btn btn-outline">
          View Full Nutrition Report
        </button>
      </div>
    </div>
  );
};

const MealPlanTab: React.FC = () => {
  return (
    <div className="card p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold text-gray-900">Your Meal Plan</h2>
        <button className="btn btn-outline py-1 px-3 text-sm">
          Regenerate Plan
        </button>
      </div>
      
      <div className="bg-primary-50 p-4 rounded-lg mb-6">
        <div className="flex items-start">
          <Info className="h-5 w-5 text-primary-600 mr-3 mt-0.5 flex-shrink-0" />
          <div>
            <h3 className="font-medium text-gray-900 mb-1">Personalized for Your Goals</h3>
            <p className="text-sm text-gray-600">
              This meal plan is designed specifically for your weight loss goal and nutritional needs. It provides approximately 2,200 calories per day with a 30% protein, 45% carb, and 25% fat macro split.
            </p>
          </div>
        </div>
      </div>
      
      <div className="space-y-6">
        <div>
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-medium text-gray-900">Monday</h3>
            <span className="text-xs px-2 py-0.5 bg-primary-100 text-primary-800 rounded-full">Today</span>
          </div>
          
          <div className="space-y-3">
            <MealCard 
              mealType="Breakfast"
              title="Protein Oatmeal Bowl"
              calories={420}
              macros={{protein: 25, carbs: 60, fat: 12}}
              image="https://images.pexels.com/photos/4916561/pexels-photo-4916561.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
            />
            
            <MealCard 
              mealType="Lunch"
              title="Mediterranean Chicken Salad"
              calories={530}
              macros={{protein: 40, carbs: 30, fat: 22}}
              image="https://images.pexels.com/photos/1365489/pexels-photo-1365489.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
            />
            
            <MealCard 
              mealType="Dinner"
              title="Baked Salmon with Quinoa"
              calories={650}
              macros={{protein: 45, carbs: 50, fat: 28}}
              image="https://images.pexels.com/photos/3580692/pexels-photo-3580692.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
            />
            
            <MealCard 
              mealType="Snack"
              title="Greek Yogurt with Berries"
              calories={180}
              macros={{protein: 15, carbs: 20, fat: 5}}
              image="https://images.pexels.com/photos/5116683/pexels-photo-5116683.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
            />
          </div>
        </div>
        
        <div className="pt-4 border-t border-gray-100">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-medium text-gray-900">Tuesday</h3>
          </div>
          
          <div className="space-y-3">
            <MealCard 
              mealType="Breakfast"
              title="Vegetable Egg Scramble"
              calories={380}
              macros={{protein: 26, carbs: 22, fat: 18}}
              image="https://images.pexels.com/photos/6066655/pexels-photo-6066655.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
            />
            
            <button className="w-full text-center py-3 border border-dashed border-gray-300 rounded-lg text-gray-500 hover:bg-gray-50 transition-colors">
              View More Days
            </button>
          </div>
        </div>
      </div>
      
      <div className="mt-6 pt-4 border-t border-gray-100">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-medium text-gray-900">Grocery List</h3>
          <button className="text-sm text-primary-600 hover:text-primary-700">
            Generate List
          </button>
        </div>
        
        <div className="relative">
          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
            <Search className="h-4 w-4 text-gray-400" />
          </div>
          <input
            type="text"
            className="input pl-10"
            placeholder="Search grocery items..."
          />
        </div>
        
        <div className="mt-3 space-y-2">
          <div className="p-3 bg-gray-50 rounded-lg">
            <div className="font-medium text-gray-900 mb-1">Proteins</div>
            <div className="space-y-1">
              <div className="flex items-center">
                <input type="checkbox" className="h-4 w-4 text-primary-600 rounded" />
                <label className="ml-2 text-sm text-gray-700">Chicken breast (500g)</label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-4 w-4 text-primary-600 rounded" />
                <label className="ml-2 text-sm text-gray-700">Salmon fillets (4)</label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-4 w-4 text-primary-600 rounded" />
                <label className="ml-2 text-sm text-gray-700">Greek yogurt (large)</label>
              </div>
            </div>
          </div>
          
          <div className="p-3 bg-gray-50 rounded-lg">
            <div className="font-medium text-gray-900 mb-1">Produce</div>
            <div className="space-y-1">
              <div className="flex items-center">
                <input type="checkbox" className="h-4 w-4 text-primary-600 rounded" />
                <label className="ml-2 text-sm text-gray-700">Mixed berries (300g)</label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-4 w-4 text-primary-600 rounded" />
                <label className="ml-2 text-sm text-gray-700">Spinach (1 bunch)</label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" className="h-4 w-4 text-primary-600 rounded" />
                <label className="ml-2 text-sm text-gray-700">Bell peppers (3)</label>
              </div>
            </div>
            <button className="mt-1 text-xs text-primary-600 hover:text-primary-700 flex items-center">
              Show more <ChevronRight className="h-3 w-3 ml-1" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

interface MealCardProps {
  mealType: string;
  title: string;
  calories: number;
  macros: {
    protein: number;
    carbs: number;
    fat: number;
  };
  image: string;
}

const MealCard: React.FC<MealCardProps> = ({ mealType, title, calories, macros, image }) => {
  return (
    <div className="bg-white border border-gray-100 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
      <div className="flex">
        <div className="w-24 h-24 flex-shrink-0">
          <img 
            src={image} 
            alt={title} 
            className="w-full h-full object-cover"
          />
        </div>
        <div className="flex-1 p-3">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-medium text-primary-600 bg-primary-50 px-2 py-0.5 rounded-full">
              {mealType}
            </span>
            <span className="text-xs text-gray-500">{calories} kcal</span>
          </div>
          <h4 className="text-sm font-medium text-gray-900 mb-1">{title}</h4>
          <div className="flex items-center text-xs text-gray-500">
            <span className="bg-secondary-100 text-secondary-800 px-1 rounded">P: {macros.protein}g</span>
            <span className="mx-1">•</span>
            <span className="bg-primary-100 text-primary-800 px-1 rounded">C: {macros.carbs}g</span>
            <span className="mx-1">•</span>
            <span className="bg-accent-100 text-accent-800 px-1 rounded">F: {macros.fat}g</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NutritionAnalysis;