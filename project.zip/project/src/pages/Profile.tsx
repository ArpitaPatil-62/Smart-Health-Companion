import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  User, 
  Edit, 
  Save, 
  Activity, 
  Heart, 
  Scale, 
  Shield,
  ChevronRight,
  BarChart
} from 'lucide-react';

const Profile: React.FC = () => {
  const [editMode, setEditMode] = useState(false);
  const [profileData, setProfileData] = useState({
    name: 'Sarah Johnson',
    email: 'sarah.johnson@example.com',
    age: 32,
    gender: 'Female',
    height: 168,
    weight: 72,
    goal: 'Weight Loss',
    conditions: ['Mild Hypertension'],
    activity: 'Moderate',
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setProfileData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex items-center mb-1">
          <User className="h-6 w-6 text-gray-700 mr-2" />
          <h1 className="text-2xl font-bold text-gray-900">Your Profile</h1>
        </div>
        <p className="text-gray-600">Manage your personal information and preferences</p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="lg:col-span-2"
        >
          <div className="card p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-gray-900">Personal Information</h2>
              <button 
                className="btn btn-outline py-1 px-3 text-sm"
                onClick={() => setEditMode(!editMode)}
              >
                {editMode ? (
                  <>
                    <Save className="h-4 w-4 mr-1" />
                    Save
                  </>
                ) : (
                  <>
                    <Edit className="h-4 w-4 mr-1" />
                    Edit
                  </>
                )}
              </button>
            </div>
            
            <div className="space-y-6">
              <div className="flex flex-col md:flex-row gap-6">
                <div className="md:w-1/3 flex flex-col items-center">
                  <div className="relative mb-3">
                    <div className="h-24 w-24 rounded-full bg-gray-200 overflow-hidden">
                      <img
                        src="https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                        alt="Profile"
                        className="h-full w-full object-cover"
                      />
                    </div>
                    {editMode && (
                      <button className="absolute bottom-0 right-0 bg-white rounded-full p-1 shadow-md hover:bg-gray-50">
                        <Edit className="h-4 w-4 text-gray-600" />
                      </button>
                    )}
                  </div>
                  <h3 className="text-lg font-medium text-gray-900">{profileData.name}</h3>
                  <p className="text-sm text-gray-500">{profileData.email}</p>
                </div>
                
                <div className="md:w-2/3 grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Full Name
                    </label>
                    {editMode ? (
                      <input
                        type="text"
                        name="name"
                        value={profileData.name}
                        onChange={handleInputChange}
                        className="input"
                      />
                    ) : (
                      <p className="text-gray-900">{profileData.name}</p>
                    )}
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Email
                    </label>
                    {editMode ? (
                      <input
                        type="email"
                        name="email"
                        value={profileData.email}
                        onChange={handleInputChange}
                        className="input"
                      />
                    ) : (
                      <p className="text-gray-900">{profileData.email}</p>
                    )}
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Age
                    </label>
                    {editMode ? (
                      <input
                        type="number"
                        name="age"
                        value={profileData.age}
                        onChange={handleInputChange}
                        className="input"
                      />
                    ) : (
                      <p className="text-gray-900">{profileData.age}</p>
                    )}
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Gender
                    </label>
                    {editMode ? (
                      <select
                        name="gender"
                        value={profileData.gender}
                        onChange={handleInputChange}
                        className="input"
                      >
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                        <option value="Prefer not to say">Prefer not to say</option>
                      </select>
                    ) : (
                      <p className="text-gray-900">{profileData.gender}</p>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="pt-4 border-t border-gray-100">
                <h3 className="text-md font-medium text-gray-900 mb-4">Health Information</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Height (cm)
                    </label>
                    {editMode ? (
                      <input
                        type="number"
                        name="height"
                        value={profileData.height}
                        onChange={handleInputChange}
                        className="input"
                      />
                    ) : (
                      <p className="text-gray-900">{profileData.height}</p>
                    )}
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Weight (kg)
                    </label>
                    {editMode ? (
                      <input
                        type="number"
                        name="weight"
                        value={profileData.weight}
                        onChange={handleInputChange}
                        className="input"
                      />
                    ) : (
                      <p className="text-gray-900">{profileData.weight}</p>
                    )}
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      BMI
                    </label>
                    <p className="text-gray-900">
                      {(profileData.weight / Math.pow(profileData.height / 100, 2)).toFixed(1)}
                    </p>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Activity Level
                    </label>
                    {editMode ? (
                      <select
                        name="activity"
                        value={profileData.activity}
                        onChange={handleInputChange}
                        className="input"
                      >
                        <option value="Sedentary">Sedentary</option>
                        <option value="Light">Light</option>
                        <option value="Moderate">Moderate</option>
                        <option value="Active">Active</option>
                        <option value="Very Active">Very Active</option>
                      </select>
                    ) : (
                      <p className="text-gray-900">{profileData.activity}</p>
                    )}
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Health Goal
                    </label>
                    {editMode ? (
                      <select
                        name="goal"
                        value={profileData.goal}
                        onChange={handleInputChange}
                        className="input"
                      >
                        <option value="Weight Loss">Weight Loss</option>
                        <option value="Maintain Weight">Maintain Weight</option>
                        <option value="Gain Weight">Gain Weight</option>
                        <option value="Improve Fitness">Improve Fitness</option>
                        <option value="Heart Health">Heart Health</option>
                      </select>
                    ) : (
                      <p className="text-gray-900">{profileData.goal}</p>
                    )}
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Medical Conditions
                    </label>
                    {editMode ? (
                      <select
                        name="conditions"
                        value={profileData.conditions[0] || ''}
                        onChange={(e) => setProfileData(prev => ({ ...prev, conditions: [e.target.value] }))}
                        className="input"
                      >
                        <option value="">None</option>
                        <option value="Mild Hypertension">Mild Hypertension</option>
                        <option value="Diabetes">Diabetes</option>
                        <option value="Heart Disease">Heart Disease</option>
                        <option value="High Cholesterol">High Cholesterol</option>
                      </select>
                    ) : (
                      <p className="text-gray-900">
                        {profileData.conditions.length ? profileData.conditions.join(', ') : 'None'}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="card p-6 mt-6"
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900">Connected Devices</h2>
              <button className="btn btn-outline py-1 px-3 text-sm">
                Add Device
              </button>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                  <div className="bg-primary-100 p-2 rounded-full mr-3">
                    <Activity className="h-5 w-5 text-primary-600" />
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-900">Apple Watch Series 8</h3>
                    <p className="text-xs text-gray-500">Last synced: Today, 9:45 AM</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <span className="text-xs bg-success-100 text-success-800 px-2 py-0.5 rounded-full mr-2">
                    Connected
                  </span>
                  <button className="text-gray-400 hover:text-gray-500">
                    <ChevronRight className="h-5 w-5" />
                  </button>
                </div>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                  <div className="bg-gray-200 p-2 rounded-full mr-3">
                    <Heart className="h-5 w-5 text-gray-500" />
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-900">Kardia Mobile ECG</h3>
                    <p className="text-xs text-gray-500">Last synced: 2 days ago</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <span className="text-xs bg-warning-100 text-warning-800 px-2 py-0.5 rounded-full mr-2">
                    Sync Needed
                  </span>
                  <button className="text-gray-400 hover:text-gray-500">
                    <ChevronRight className="h-5 w-5" />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
        
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <div className="space-y-6">
            <div className="card p-4">
              <h2 className="text-lg font-semibold text-gray-900 mb-3">Health Status</h2>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Heart className="h-5 w-5 text-secondary-500 mr-2" />
                    <span className="text-sm font-medium text-gray-700">Heart Health</span>
                  </div>
                  <div className="flex items-center text-success-600">
                    <div className="h-2 w-2 rounded-full bg-success-500 mr-1.5"></div>
                    <span className="text-sm">Good</span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Scale className="h-5 w-5 text-accent-500 mr-2" />
                    <span className="text-sm font-medium text-gray-700">Weight</span>
                  </div>
                  <div className="flex items-center text-warning-600">
                    <div className="h-2 w-2 rounded-full bg-warning-500 mr-1.5"></div>
                    <span className="text-sm">Moderate</span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Activity className="h-5 w-5 text-primary-500 mr-2" />
                    <span className="text-sm font-medium text-gray-700">Activity</span>
                  </div>
                  <div className="flex items-center text-success-600">
                    <div className="h-2 w-2 rounded-full bg-success-500 mr-1.5"></div>
                    <span className="text-sm">Good</span>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="card p-4">
              <h2 className="text-lg font-semibold text-gray-900 mb-3">Account Settings</h2>
              
              <div className="space-y-2">
                <button className="w-full flex items-center justify-between p-2 hover:bg-gray-50 rounded-lg transition-colors">
                  <div className="flex items-center">
                    <Shield className="h-5 w-5 text-gray-500 mr-2" />
                    <span className="text-sm text-gray-700">Privacy Settings</span>
                  </div>
                  <ChevronRight className="h-5 w-5 text-gray-400" />
                </button>
                
                <button className="w-full flex items-center justify-between p-2 hover:bg-gray-50 rounded-lg transition-colors">
                  <div className="flex items-center">
                    <BarChart className="h-5 w-5 text-gray-500 mr-2" />
                    <span className="text-sm text-gray-700">Data Export</span>
                  </div>
                  <ChevronRight className="h-5 w-5 text-gray-400" />
                </button>
                
                <button className="w-full flex items-center justify-between p-2 hover:bg-gray-50 rounded-lg transition-colors">
                  <div className="flex items-center">
                    <User className="h-5 w-5 text-gray-500 mr-2" />
                    <span className="text-sm text-gray-700">Account Security</span>
                  </div>
                  <ChevronRight className="h-5 w-5 text-gray-400" />
                </button>
              </div>
            </div>
            
            <div className="card p-4">
              <h2 className="text-lg font-semibold text-gray-900 mb-3">Subscription</h2>
              
              <div className="bg-primary-50 p-3 rounded-lg mb-3">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium text-gray-900">Premium Plan</span>
                  <span className="text-xs bg-primary-200 text-primary-800 px-2 py-0.5 rounded-full">
                    Active
                  </span>
                </div>
                <p className="text-xs text-gray-600">
                  Next billing: April 15, 2025
                </p>
              </div>
              
              <button className="btn btn-outline w-full text-sm">
                Manage Subscription
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Profile;