import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Activity, Heart, Brain, Utensils, Share2, ChevronRight } from 'lucide-react';

const Welcome: React.FC = () => {
  return (
    <div className="min-h-screen animated-bg">
      <div className="container mx-auto px-4 py-12 md:py-20">
        <header className="text-center mb-12 md:mb-16">
          <motion.div
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="flex items-center justify-center mb-4"
          >
            <Activity className="h-12 w-12 text-primary-500 floating" />
            <h1 className="text-4xl md:text-5xl font-bold ml-2">
              Health<span className="text-gradient">Companion</span>
            </h1>
          </motion.div>
          <motion.p 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-lg md:text-xl text-gray-600 max-w-2xl mx-auto"
          >
            Your AI-powered health assistant for personalized ECG analysis and nutrition guidance
          </motion.p>
        </header>

        <motion.div 
          initial={{ y: 40, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="max-w-6xl mx-auto mb-16"
        >
          <div className="glass rounded-2xl shadow-xl overflow-hidden backdrop-blur-xl">
            <div className="md:flex">
              <div className="md:w-1/2 p-8 md:p-12">
                <motion.div
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ duration: 0.5, delay: 0.3 }}
                >
                  <h2 className="text-3xl md:text-4xl font-bold mb-4">
                    Your Health, <span className="text-gradient">Simplified</span>
                  </h2>
                  <p className="text-gray-600 mb-8 text-lg">
                    Experience the future of healthcare with our AI-powered platform that provides instant ECG diagnostics and personalized nutrition plans tailored to your unique health profile.
                  </p>
                  <div className="space-y-4">
                    <Link 
                      to="/onboarding"
                      className="btn btn-primary w-full text-lg py-3 ripple hover-lift"
                    >
                      Get Started
                      <ChevronRight className="ml-2 h-5 w-5" />
                    </Link>
                    <button className="btn btn-outline w-full text-lg py-3 ripple">
                      Watch Demo
                    </button>
                  </div>
                </motion.div>
              </div>
              <div className="md:w-1/2 bg-gradient-primary p-8 md:p-12 text-white relative overflow-hidden">
                <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/7579831/pexels-photo-7579831.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2')] bg-cover bg-center mix-blend-overlay opacity-20"></div>
                <motion.img 
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ duration: 0.5, delay: 0.4 }}
                  src="https://images.pexels.com/photos/7579831/pexels-photo-7579831.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                  alt="Health monitoring" 
                  className="rounded-lg shadow-2xl mx-auto h-64 object-cover hover-lift"
                />
              </div>
            </div>
          </div>
        </motion.div>

        <motion.div 
          initial={{ y: 60, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.7, delay: 0.5 }}
          className="max-w-6xl mx-auto"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Key <span className="text-gradient">Features</span>
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <motion.div
              whileHover={{ scale: 1.05 }}
              transition={{ type: "spring", stiffness: 300 }}
              className="card card-hover glass p-8"
            >
              <div className="rounded-full bg-gradient-primary p-4 w-16 h-16 flex items-center justify-center mb-6 floating">
                <Heart className="text-white h-8 w-8" />
              </div>
              <h3 className="text-2xl font-semibold mb-4">ECG Analysis</h3>
              <p className="text-gray-600 text-lg">
                Upload ECG images or connect your wearable device for instant AI-powered cardiac analysis.
              </p>
            </motion.div>

            <motion.div
              whileHover={{ scale: 1.05 }}
              transition={{ type: "spring", stiffness: 300 }}
              className="card card-hover glass p-8"
            >
              <div className="rounded-full bg-gradient-secondary p-4 w-16 h-16 flex items-center justify-center mb-6 floating">
                <Utensils className="text-white h-8 w-8" />
              </div>
              <h3 className="text-2xl font-semibold mb-4">Nutrition Planning</h3>
              <p className="text-gray-600 text-lg">
                Get personalized nutrition advice based on your body metrics, goals, and activity level.
              </p>
            </motion.div>

            <motion.div
              whileHover={{ scale: 1.05 }}
              transition={{ type: "spring", stiffness: 300 }}
              className="card card-hover glass p-8"
            >
              <div className="rounded-full bg-gradient-accent p-4 w-16 h-16 flex items-center justify-center mb-6 floating">
                <Share2 className="text-white h-8 w-8" />
              </div>
              <h3 className="text-2xl font-semibold mb-4">Data Integration</h3>
              <p className="text-gray-600 text-lg">
                Seamlessly sync with your fitness trackers and share reports with healthcare providers.
              </p>
            </motion.div>
          </div>

          <motion.div
            initial={{ y: 40, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="mt-16 text-center"
          >
            <Link
              to="/onboarding"
              className="btn btn-primary text-lg py-3 px-8 ripple hover-lift inline-flex items-center"
            >
              Start Your Health Journey
              <ChevronRight className="ml-2 h-5 w-5" />
            </Link>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
};

export default Welcome;