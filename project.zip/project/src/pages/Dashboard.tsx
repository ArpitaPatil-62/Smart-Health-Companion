import React from 'react';
import { motion } from 'framer-motion';
import { Heart, Activity, Utensils, Droplet, BarChart3, AlertTriangle } from 'lucide-react';
import HealthMetricCard from '../components/dashboard/HealthMetricCard';
import TrendChart from '../components/dashboard/TrendChart';
import RecentActivity from '../components/dashboard/RecentActivity';
import HealthTip from '../components/dashboard/HealthTip';

const Dashboard: React.FC = () => {
  return (
    <div className="space-y-6">
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-2xl font-bold text-gray-900 mb-1">Welcome back, Sarah!</h1>
        <p className="text-gray-600">Here's your health overview for today</p>
      </motion.div>

      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"
      >
        <HealthMetricCard
          title="Heart Rate"
          value="72"
          unit="bpm"
          status="normal"
          icon={<Heart className="text-secondary-500" />}
          trend={-3}
        />
        
        <HealthMetricCard
          title="ECG Status"
          value="Normal"
          status="normal"
          icon={<Activity className="text-success-500" />}
          lastChecked="Today, 8:45 AM"
        />
        
        <HealthMetricCard
          title="Calories"
          value="1,450"
          unit="kcal"
          status="warning"
          progress={0.65}
          target="2,200"
          icon={<Utensils className="text-accent-500" />}
        />
        
        <HealthMetricCard
          title="Hydration"
          value="1.2"
          unit="L"
          status="alert"
          progress={0.4}
          target="3.0"
          icon={<Droplet className="text-primary-500" />}
        />
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="lg:col-span-2"
        >
          <div className="card p-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900">Health Trends</h2>
              <select className="input max-w-xs py-1 px-2 text-sm">
                <option>Last 7 Days</option>
                <option>Last 30 Days</option>
                <option>Last 3 Months</option>
              </select>
            </div>
            <TrendChart />
          </div>
        </motion.div>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <div className="card p-4 h-full">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Insights</h2>
            
            <div className="space-y-4">
              <div className="flex items-start p-3 bg-warning-50 rounded-lg">
                <AlertTriangle className="h-5 w-5 text-warning-500 mr-2 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-medium text-gray-900">Low Hydration</h3>
                  <p className="text-sm text-gray-600">You're 60% below your daily hydration goal. Consider drinking more water.</p>
                </div>
              </div>
              
              <div className="flex items-start p-3 bg-success-50 rounded-lg">
                <Activity className="h-5 w-5 text-success-500 mr-2 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-medium text-gray-900">Heart Rate Stable</h3>
                  <p className="text-sm text-gray-600">Your resting heart rate has been consistent over the past week.</p>
                </div>
              </div>
              
              <HealthTip />
            </div>
          </div>
        </motion.div>
      </div>

      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.4 }}
      >
        <div className="card p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Recent Activity</h2>
            <button className="text-sm text-primary-600 hover:text-primary-700">View All</button>
          </div>
          <RecentActivity />
        </div>
      </motion.div>
    </div>
  );
};

export default Dashboard;