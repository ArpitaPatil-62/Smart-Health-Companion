import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Activity, 
  ChevronRight, 
  ChevronLeft, 
  User, 
  Scale, 
  Target, 
  Heart 
} from 'lucide-react';

const Onboarding: React.FC = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    gender: '',
    height: '',
    weight: '',
    goal: '',
    conditions: [] as string[],
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      conditions: checked 
        ? [...prev.conditions, value]
        : prev.conditions.filter(condition => condition !== value)
    }));
  };

  const handleNext = () => {
    if (step < 3) {
      setStep(step + 1);
    } else {
      navigate('/dashboard');
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary-50 to-white flex flex-col">
      <header className="py-4 px-6 flex items-center">
        <Activity className="h-8 w-8 text-primary-500" />
        <h1 className="text-xl font-semibold ml-2">HealthCompanion</h1>
      </header>

      <div className="flex-1 flex flex-col items-center justify-center px-4 py-8">
        <motion.div
          key={step}
          initial={{ x: 20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: -20, opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="max-w-md w-full bg-white rounded-xl shadow-lg p-6 md:p-8"
        >
          <div className="mb-6">
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-xl font-bold text-gray-900">
                {step === 1 && "Personal Information"}
                {step === 2 && "Body Metrics"}
                {step === 3 && "Health Profile"}
              </h2>
              <span className="text-sm text-gray-500">Step {step} of 3</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-1.5">
              <div 
                className="bg-primary-500 h-1.5 rounded-full transition-all duration-300" 
                style={{ width: `${(step / 3) * 100}%` }}
              ></div>
            </div>
          </div>

          {step === 1 && (
            <div className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  className="input"
                  placeholder="Enter your full name"
                  required
                />
              </div>
              <div>
                <label htmlFor="age" className="block text-sm font-medium text-gray-700 mb-1">
                  Age
                </label>
                <input
                  type="number"
                  id="age"
                  name="age"
                  value={formData.age}
                  onChange={handleInputChange}
                  className="input"
                  placeholder="Enter your age"
                  required
                />
              </div>
              <div>
                <label htmlFor="gender" className="block text-sm font-medium text-gray-700 mb-1">
                  Gender
                </label>
                <select
                  id="gender"
                  name="gender"
                  value={formData.gender}
                  onChange={handleInputChange}
                  className="input"
                  required
                >
                  <option value="" disabled>Select your gender</option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                  <option value="prefer-not-to-say">Prefer not to say</option>
                </select>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div className="flex items-center space-x-4">
                <div className="flex-1">
                  <label htmlFor="height" className="block text-sm font-medium text-gray-700 mb-1">
                    Height (cm)
                  </label>
                  <input
                    type="number"
                    id="height"
                    name="height"
                    value={formData.height}
                    onChange={handleInputChange}
                    className="input"
                    placeholder="Height in cm"
                    required
                  />
                </div>
                <div className="flex-1">
                  <label htmlFor="weight" className="block text-sm font-medium text-gray-700 mb-1">
                    Weight (kg)
                  </label>
                  <input
                    type="number"
                    id="weight"
                    name="weight"
                    value={formData.weight}
                    onChange={handleInputChange}
                    className="input"
                    placeholder="Weight in kg"
                    required
                  />
                </div>
              </div>
              <div>
                <label htmlFor="goal" className="block text-sm font-medium text-gray-700 mb-1">
                  Primary Health Goal
                </label>
                <select
                  id="goal"
                  name="goal"
                  value={formData.goal}
                  onChange={handleInputChange}
                  className="input"
                  required
                >
                  <option value="" disabled>Select your goal</option>
                  <option value="heart-health">Improve Heart Health</option>
                  <option value="weight-loss">Weight Loss</option>
                  <option value="muscle-gain">Muscle Gain</option>
                  <option value="better-nutrition">Better Nutrition</option>
                  <option value="monitor-condition">Monitor Existing Condition</option>
                </select>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Pre-existing Health Conditions
                </label>
                <div className="space-y-2">
                  {['Hypertension', 'Diabetes', 'Heart Disease', 'High Cholesterol', 'None'].map((condition) => (
                    <div key={condition} className="flex items-center">
                      <input
                        type="checkbox"
                        id={condition.toLowerCase().replace(' ', '-')}
                        name="conditions"
                        value={condition}
                        checked={formData.conditions.includes(condition)}
                        onChange={handleCheckboxChange}
                        className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                      />
                      <label
                        htmlFor={condition.toLowerCase().replace(' ', '-')}
                        className="ml-2 block text-sm text-gray-700"
                      >
                        {condition}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-sm text-gray-600 mt-2">
                  By completing this onboarding, you agree to our{' '}
                  <a href="#" className="text-primary-600 hover:text-primary-500">
                    Terms of Service
                  </a>{' '}
                  and{' '}
                  <a href="#" className="text-primary-600 hover:text-primary-500">
                    Privacy Policy
                  </a>
                  .
                </p>
              </div>
            </div>
          )}

          <div className="mt-6 flex items-center justify-between">
            <button
              onClick={handleBack}
              className={`btn ${step === 1 ? 'invisible' : 'btn-outline'}`}
            >
              <ChevronLeft className="h-4 w-4 mr-1" />
              Back
            </button>
            <button
              onClick={handleNext}
              className="btn btn-primary"
            >
              {step < 3 ? 'Next' : 'Complete'}
              <ChevronRight className="h-4 w-4 ml-1" />
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Onboarding;