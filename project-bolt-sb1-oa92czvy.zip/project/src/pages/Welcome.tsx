import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Activity, Heart, Brain, Utensils, Share2 } from 'lucide-react';

const Welcome: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-primary-50 to-white">
      <div className="container mx-auto px-4 py-12 md:py-20">
        <header className="text-center mb-12 md:mb-16">
          <motion.div
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="flex items-center justify-center mb-4"
          >
            <Activity className="h-10 w-10 text-primary-500" />
            <h1 className="text-3xl md:text-4xl font-bold ml-2 text-gray-900">
              Health<span className="text-primary-500">Companion</span>
            </h1>
          </motion.div>
          <motion.p 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-lg md:text-xl text-gray-600 max-w-2xl mx-auto"
          >
            Your AI-powered health assistant for personalized ECG analysis and nutrition guidance
          </motion.p>
        </header>

        <motion.div 
          initial={{ y: 40, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="max-w-5xl mx-auto mb-16"
        >
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
            <div className="md:flex">
              <div className="md:w-1/2 p-8 md:p-12">
                <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">
                  Your Health, Simplified
                </h2>
                <p className="text-gray-600 mb-6">
                  HealthCompanion uses artificial intelligence to provide instant ECG diagnostics and personalized nutrition plans tailored to your unique health profile.
                </p>
                <div className="space-y-4">
                  <Link 
                    to="/onboarding"
                    className="btn btn-primary w-full"
                  >
                    Get Started
                  </Link>
                  <button className="btn btn-outline w-full">
                    Learn More
                  </button>
                </div>
              </div>
              <div className="md:w-1/2 bg-primary-500 p-8 md:p-12 text-white">
                <img 
                  src="https://images.pexels.com/photos/7579831/pexels-photo-7579831.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                  alt="Health monitoring" 
                  className="rounded-lg shadow-lg mx-auto h-64 object-cover"
                />
              </div>
            </div>
          </div>
        </motion.div>

        <motion.div 
          initial={{ y: 60, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="max-w-5xl mx-auto"
        >
          <h2 className="text-2xl md:text-3xl font-bold text-center text-gray-900 mb-8">
            Key Features
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="card card-hover p-6">
              <div className="rounded-full bg-primary-100 p-3 w-12 h-12 flex items-center justify-center mb-4">
                <Heart className="text-primary-500 h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold mb-2">ECG Analysis</h3>
              <p className="text-gray-600">
                Upload ECG images or connect your wearable device for instant AI-powered cardiac analysis.
              </p>
            </div>

            <div className="card card-hover p-6">
              <div className="rounded-full bg-secondary-100 p-3 w-12 h-12 flex items-center justify-center mb-4">
                <Utensils className="text-secondary-500 h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Nutrition Planning</h3>
              <p className="text-gray-600">
                Get personalized nutrition advice based on your body metrics, goals, and activity level.
              </p>
            </div>

            <div className="card card-hover p-6">
              <div className="rounded-full bg-accent-100 p-3 w-12 h-12 flex items-center justify-center mb-4">
                <Share2 className="text-accent-500 h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Data Integration</h3>
              <p className="text-gray-600">
                Seamlessly sync with your fitness trackers and share reports with healthcare providers.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Welcome;