import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Heart, Upload, Clock, FileText, Share2, AlertTriangle } from 'lucide-react';

const EcgDiagnostic: React.FC = () => {
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [analyzed, setAnalyzed] = useState(false);
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setUploadedFile(e.target.files[0]);
    }
  };
  
  const handleAnalyze = () => {
    if (!uploadedFile) return;
    
    setAnalyzing(true);
    
    // Simulate analysis delay
    setTimeout(() => {
      setAnalyzing(false);
      setAnalyzed(true);
    }, 2500);
  };
  
  const resetAnalysis = () => {
    setUploadedFile(null);
    setAnalyzed(false);
  };

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex items-center mb-1">
          <Heart className="h-6 w-6 text-secondary-500 mr-2" />
          <h1 className="text-2xl font-bold text-gray-900">ECG Diagnostic Tool</h1>
        </div>
        <p className="text-gray-600">Upload an ECG image or connect a device for real-time analysis</p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="lg:col-span-2"
        >
          <div className="card p-6 h-full">
            {!analyzed ? (
              <div className="h-full flex flex-col">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Upload ECG</h2>
                
                <div className="flex-1 flex flex-col items-center justify-center">
                  {!uploadedFile ? (
                    <label className="w-full max-w-md h-64 flex flex-col items-center justify-center border-2 border-dashed border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
                      <Upload className="h-12 w-12 text-gray-400 mb-3" />
                      <p className="text-gray-700 font-medium">Drag & Drop your ECG file here</p>
                      <p className="text-sm text-gray-500 mt-1">or click to browse files</p>
                      <p className="text-xs text-gray-400 mt-3">Supported formats: JPG, PNG, PDF</p>
                      <input
                        type="file"
                        accept=".jpg,.jpeg,.png,.pdf"
                        className="hidden"
                        onChange={handleFileChange}
                      />
                    </label>
                  ) : (
                    <div className="w-full max-w-md">
                      <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg mb-4">
                        <div className="flex items-center">
                          <FileText className="h-6 w-6 text-gray-500 mr-2" />
                          <div className="flex-1 mr-2 truncate">
                            <p className="font-medium text-gray-800">{uploadedFile.name}</p>
                            <p className="text-xs text-gray-500">
                              {(uploadedFile.size / 1024).toFixed(1)} KB
                            </p>
                          </div>
                          <button 
                            className="text-gray-500 hover:text-error-500"
                            onClick={() => setUploadedFile(null)}
                          >
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                          </button>
                        </div>
                      </div>
                      
                      <button
                        onClick={handleAnalyze}
                        className="btn btn-primary w-full"
                        disabled={analyzing}
                      >
                        {analyzing ? (
                          <>
                            <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            Analyzing ECG...
                          </>
                        ) : 'Analyze ECG'}
                      </button>
                    </div>
                  )}
                </div>
                
                <div className="mt-6 pt-4 border-t border-gray-100">
                  <h3 className="text-sm font-medium text-gray-700 mb-2">Connect a device</h3>
                  <button className="btn btn-outline w-full mb-2">
                    <Heart className="mr-2 h-4 w-4" />
                    Connect Wearable ECG
                  </button>
                  <p className="text-xs text-gray-500">
                    Compatible with most major ECG monitors and smartwatches
                  </p>
                </div>
              </div>
            ) : (
              <div className="h-full flex flex-col">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-semibold text-gray-900">ECG Analysis Results</h2>
                  <div className="flex items-center text-xs text-gray-500">
                    <Clock className="h-3 w-3 mr-1" />
                    <span>Analyzed at 10:32 AM, Today</span>
                  </div>
                </div>
                
                <div className="flex-1">
                  <div className="border border-success-200 bg-success-50 rounded-lg p-4 mb-6">
                    <div className="flex items-center mb-2">
                      <Heart className="h-5 w-5 text-success-500 mr-2" />
                      <h3 className="font-semibold text-gray-900">Normal Sinus Rhythm</h3>
                      <span className="ml-auto text-sm bg-success-100 text-success-700 px-2 py-0.5 rounded-full">
                        98% Confidence
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 mb-3">
                      Your ECG shows a healthy heart rhythm with no significant abnormalities detected.
                    </p>
                    <div className="flex items-center text-sm text-success-700">
                      <Heart className="h-4 w-4 mr-1" />
                      <span>Heart rate: 72 BPM (Normal range)</span>
                    </div>
                  </div>
                  
                  <div className="bg-white border border-gray-200 rounded-lg overflow-hidden mb-6">
                    <img 
                      src="https://images.pexels.com/photos/7089401/pexels-photo-7089401.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                      alt="ECG Graph" 
                      className="w-full h-auto object-cover"
                    />
                  </div>
                  
                  <div className="space-y-3">
                    <h3 className="font-medium text-gray-900">Additional Insights</h3>
                    <div className="flex items-start">
                      <div className="bg-primary-100 p-1 rounded-full mr-2 mt-0.5">
                        <Heart className="h-4 w-4 text-primary-500" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-700 font-medium">Regular P-waves</p>
                        <p className="text-xs text-gray-600">Indicates normal atrial activity</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <div className="bg-primary-100 p-1 rounded-full mr-2 mt-0.5">
                        <Heart className="h-4 w-4 text-primary-500" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-700 font-medium">Normal QRS complexes</p>
                        <p className="text-xs text-gray-600">Showing healthy ventricular contraction</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6 pt-4 border-t border-gray-100 flex flex-wrap gap-2">
                  <button className="btn btn-primary flex-1">
                    <FileText className="mr-1 h-4 w-4" />
                    Save to Health Record
                  </button>
                  <button className="btn btn-outline">
                    <Share2 className="mr-1 h-4 w-4" />
                    Share
                  </button>
                  <button 
                    className="btn btn-outline"
                    onClick={resetAnalysis}
                  >
                    <Upload className="mr-1 h-4 w-4" />
                    Upload New
                  </button>
                </div>
              </div>
            )}
          </div>
        </motion.div>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <div className="space-y-4">
            <div className="card p-4">
              <h2 className="text-lg font-semibold text-gray-900 mb-3">Previous Scans</h2>
              <div className="space-y-3">
                <div className="flex items-center p-2 hover:bg-gray-50 rounded-lg transition-colors cursor-pointer">
                  <Heart className="h-5 w-5 text-success-500 mr-2" />
                  <div className="flex-1">
                    <h3 className="text-sm font-medium">Normal Sinus Rhythm</h3>
                    <p className="text-xs text-gray-500">Yesterday, 4:32 PM</p>
                  </div>
                  <FileText className="h-4 w-4 text-gray-400" />
                </div>
                
                <div className="flex items-center p-2 hover:bg-gray-50 rounded-lg transition-colors cursor-pointer">
                  <Heart className="h-5 w-5 text-warning-500 mr-2" />
                  <div className="flex-1">
                    <h3 className="text-sm font-medium">Mild Tachycardia</h3>
                    <p className="text-xs text-gray-500">Mar 15, 2025</p>
                  </div>
                  <FileText className="h-4 w-4 text-gray-400" />
                </div>
                
                <div className="flex items-center p-2 hover:bg-gray-50 rounded-lg transition-colors cursor-pointer">
                  <Heart className="h-5 w-5 text-success-500 mr-2" />
                  <div className="flex-1">
                    <h3 className="text-sm font-medium">Normal Sinus Rhythm</h3>
                    <p className="text-xs text-gray-500">Mar 10, 2025</p>
                  </div>
                  <FileText className="h-4 w-4 text-gray-400" />
                </div>
              </div>
              <button className="text-sm text-primary-600 hover:text-primary-700 mt-2 w-full text-center">
                View All History
              </button>
            </div>
            
            <div className="card p-4">
              <h2 className="text-lg font-semibold text-gray-900 mb-3">Understanding ECG</h2>
              <p className="text-sm text-gray-600 mb-3">
                An electrocardiogram (ECG) records the electrical activity of your heart to help diagnose various heart conditions.
              </p>
              <div className="space-y-2">
                <div className="flex items-start">
                  <div className="bg-gray-100 p-1 rounded-full mr-2 mt-0.5">
                    <Heart className="h-3 w-3 text-gray-500" />
                  </div>
                  <p className="text-xs text-gray-600">P wave: Atrial depolarization</p>
                </div>
                <div className="flex items-start">
                  <div className="bg-gray-100 p-1 rounded-full mr-2 mt-0.5">
                    <Heart className="h-3 w-3 text-gray-500" />
                  </div>
                  <p className="text-xs text-gray-600">QRS complex: Ventricular depolarization</p>
                </div>
                <div className="flex items-start">
                  <div className="bg-gray-100 p-1 rounded-full mr-2 mt-0.5">
                    <Heart className="h-3 w-3 text-gray-500" />
                  </div>
                  <p className="text-xs text-gray-600">T wave: Ventricular repolarization</p>
                </div>
              </div>
              <a href="#" className="text-sm text-primary-600 hover:text-primary-700 block mt-2">
                Learn More About ECG Readings →
              </a>
            </div>
            
            <div className="flex items-center p-4 bg-warning-50 border border-warning-200 rounded-lg">
              <AlertTriangle className="h-5 w-5 text-warning-500 mr-3 flex-shrink-0" />
              <p className="text-sm text-gray-700">
                Always consult with a healthcare professional about your ECG results.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default EcgDiagnostic;