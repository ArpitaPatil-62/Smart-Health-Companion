import React from 'react';
import { 
  Heart, 
  Utensils, 
  Activity, 
  Clock
} from 'lucide-react';

const activities = [
  {
    type: 'ecg',
    title: 'ECG Scan',
    description: 'Normal sinus rhythm detected',
    time: '8:45 AM',
    icon: <Heart className="h-5 w-5 text-secondary-500" />,
  },
  {
    type: 'meal',
    title: 'Breakfast',
    description: '420 calories, 22g protein',
    time: '7:30 AM',
    icon: <Utensils className="h-5 w-5 text-accent-500" />,
  },
  {
    type: 'exercise',
    title: 'Morning Run',
    description: '3.2 km, 24 minutes',
    time: '6:15 AM',
    icon: <Activity className="h-5 w-5 text-primary-500" />,
  },
  {
    type: 'sleep',
    title: 'Sleep',
    description: '7h 15m, 92% quality',
    time: '10:30 PM - 5:45 AM',
    icon: <Clock className="h-5 w-5 text-gray-500" />,
  },
];

const RecentActivity: React.FC = () => {
  return (
    <div className="divide-y divide-gray-100">
      {activities.map((activity, index) => (
        <div key={index} className="py-3 first:pt-0 last:pb-0">
          <div className="flex items-start">
            <div className="rounded-full p-2 mr-3 bg-gray-100">
              {activity.icon}
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h3 className="font-medium text-gray-900">{activity.title}</h3>
                <span className="text-xs text-gray-500">{activity.time}</span>
              </div>
              <p className="text-sm text-gray-600">{activity.description}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default RecentActivity;