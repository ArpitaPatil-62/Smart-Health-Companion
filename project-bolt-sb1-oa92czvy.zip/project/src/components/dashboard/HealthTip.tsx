import React, { useState, useEffect } from 'react';
import { Lightbulb as LightBulb } from 'lucide-react';

const tips = [
  "Try to drink at least 8 glasses of water daily for optimal hydration.",
  "Incorporating 30 minutes of moderate exercise daily can improve heart health.",
  "Adding more leafy greens to your diet can help lower blood pressure.",
  "Regular sleep patterns help regulate heart rhythm and improve ECG readings.",
  "Consider replacing refined carbs with whole grains for better heart health."
];

const HealthTip: React.FC = () => {
  const [currentTipIndex, setCurrentTipIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setIsAnimating(true);
      setTimeout(() => {
        setCurrentTipIndex(prev => (prev + 1) % tips.length);
        setIsAnimating(false);
      }, 500);
    }, 10000); // Change tip every 10 seconds

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex items-start p-3 bg-primary-50 rounded-lg overflow-hidden">
      <LightBulb className="h-5 w-5 text-primary-500 mr-2 flex-shrink-0 mt-0.5" />
      <div className="relative h-14">
        <div 
          className={`absolute transition-all duration-500 ease-in-out ${
            isAnimating ? 'opacity-0 transform -translate-y-2' : 'opacity-100 transform translate-y-0'
          }`}
        >
          <h3 className="font-medium text-gray-900">Health Tip</h3>
          <p className="text-sm text-gray-600">{tips[currentTipIndex]}</p>
        </div>
      </div>
    </div>
  );
};

export default HealthTip;