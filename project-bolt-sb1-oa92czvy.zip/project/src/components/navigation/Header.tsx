import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { 
  Bell, 
  Menu,
  X,
  Activity, 
  Home, 
  Heart, 
  Utensils, 
  User,
} from 'lucide-react';

const Header: React.FC = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
      <div className="flex items-center justify-between px-4 py-2 md:py-3">
        <div className="flex items-center md:hidden">
          <button
            type="button"
            className="text-gray-500 hover:text-gray-600"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? (
              <X className="h-6 w-6" />
            ) : (
              <Menu className="h-6 w-6" />
            )}
          </button>
          <div className="ml-3 flex items-center md:hidden">
            <Activity className="h-6 w-6 text-primary-500" />
            <span className="ml-1 font-semibold text-gray-900">HealthCompanion</span>
          </div>
        </div>
        
        <div className="hidden md:flex md:flex-1">
          <h1 className="text-xl font-semibold text-gray-900">Dashboard</h1>
        </div>
        
        <div className="flex items-center">
          <button className="relative p-1 text-gray-500 hover:text-gray-600 rounded-full hover:bg-gray-100">
            <Bell className="h-5 w-5" />
            <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-secondary-500 ring-2 ring-white"></span>
          </button>
          
          <div className="ml-3 relative">
            <div className="flex items-center">
              <img
                className="h-8 w-8 rounded-full"
                src="https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                alt="User"
              />
              <span className="hidden md:block ml-2 text-sm font-medium text-gray-700">
                Sarah Johnson
              </span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      {mobileMenuOpen && (
        <nav className="px-2 pt-2 pb-4 bg-white border-b border-gray-200 md:hidden">
          <NavLink 
            to="/dashboard" 
            className={({isActive}) => 
              `flex items-center px-3 py-2 text-base font-medium rounded-md mb-1 ${
                isActive 
                  ? 'bg-primary-50 text-primary-700' 
                  : 'text-gray-700 hover:bg-gray-100'
              }`
            }
            onClick={() => setMobileMenuOpen(false)}
          >
            <Home className="mr-3 h-5 w-5" />
            <span>Dashboard</span>
          </NavLink>
          
          <NavLink 
            to="/ecg" 
            className={({isActive}) => 
              `flex items-center px-3 py-2 text-base font-medium rounded-md mb-1 ${
                isActive 
                  ? 'bg-primary-50 text-primary-700' 
                  : 'text-gray-700 hover:bg-gray-100'
              }`
            }
            onClick={() => setMobileMenuOpen(false)}
          >
            <Heart className="mr-3 h-5 w-5" />
            <span>ECG Diagnostics</span>
          </NavLink>
          
          <NavLink 
            to="/nutrition" 
            className={({isActive}) => 
              `flex items-center px-3 py-2 text-base font-medium rounded-md mb-1 ${
                isActive 
                  ? 'bg-primary-50 text-primary-700' 
                  : 'text-gray-700 hover:bg-gray-100'
              }`
            }
            onClick={() => setMobileMenuOpen(false)}
          >
            <Utensils className="mr-3 h-5 w-5" />
            <span>Nutrition</span>
          </NavLink>
          
          <NavLink 
            to="/profile" 
            className={({isActive}) => 
              `flex items-center px-3 py-2 text-base font-medium rounded-md mb-1 ${
                isActive 
                  ? 'bg-primary-50 text-primary-700' 
                  : 'text-gray-700 hover:bg-gray-100'
              }`
            }
            onClick={() => setMobileMenuOpen(false)}
          >
            <User className="mr-3 h-5 w-5" />
            <span>Profile</span>
          </NavLink>
        </nav>
      )}
    </header>
  );
};

export default Header;