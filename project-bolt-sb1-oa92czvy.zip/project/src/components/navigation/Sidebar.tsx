import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  Activity, 
  Home, 
  Heart, 
  Utensils, 
  User,
  Settings,
  HelpCircle,
  LogOut
} from 'lucide-react';

const Sidebar: React.FC = () => {
  return (
    <aside className="hidden md:flex flex-col w-64 border-r border-gray-200 bg-white">
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center">
          <Activity className="h-8 w-8 text-primary-500" />
          <span className="ml-2 text-lg font-semibold text-gray-900">HealthCompanion</span>
        </div>
      </div>
      
      <nav className="flex-1 px-2 py-4 space-y-1">
        <NavLink 
          to="/dashboard" 
          className={({isActive}) => 
            `flex items-center px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
              isActive 
                ? 'bg-primary-50 text-primary-700' 
                : 'text-gray-700 hover:bg-gray-100'
            }`
          }
        >
          <Home className="mr-3 h-5 w-5" />
          <span>Dashboard</span>
        </NavLink>
        
        <NavLink 
          to="/ecg" 
          className={({isActive}) => 
            `flex items-center px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
              isActive 
                ? 'bg-primary-50 text-primary-700' 
                : 'text-gray-700 hover:bg-gray-100'
            }`
          }
        >
          <Heart className="mr-3 h-5 w-5" />
          <span>ECG Diagnostics</span>
        </NavLink>
        
        <NavLink 
          to="/nutrition" 
          className={({isActive}) => 
            `flex items-center px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
              isActive 
                ? 'bg-primary-50 text-primary-700' 
                : 'text-gray-700 hover:bg-gray-100'
            }`
          }
        >
          <Utensils className="mr-3 h-5 w-5" />
          <span>Nutrition</span>
        </NavLink>
        
        <NavLink 
          to="/profile" 
          className={({isActive}) => 
            `flex items-center px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
              isActive 
                ? 'bg-primary-50 text-primary-700' 
                : 'text-gray-700 hover:bg-gray-100'
            }`
          }
        >
          <User className="mr-3 h-5 w-5" />
          <span>Profile</span>
        </NavLink>
      </nav>
      
      <div className="p-4 border-t border-gray-200">
        <button className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 rounded-lg hover:bg-gray-100 w-full transition-colors">
          <Settings className="mr-3 h-5 w-5" />
          <span>Settings</span>
        </button>
        
        <button className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 rounded-lg hover:bg-gray-100 w-full transition-colors">
          <HelpCircle className="mr-3 h-5 w-5" />
          <span>Help</span>
        </button>
        
        <button className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 rounded-lg hover:bg-gray-100 w-full transition-colors">
          <LogOut className="mr-3 h-5 w-5" />
          <span>Logout</span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;